import pandas as pd
import folium
import requests
from folium.plugins import MarkerCluster
from folium import FeatureGroup, LayerControl

# Steg 1: Läs in sensordata från CSV-fil
sensors_df = pd.read_csv('sensors.csv')

# Skapa karta centrerad på Borlänge
m = folium.Map(location=[60.4857, 15.4264], zoom_start=10)

# Steg 2: Lägg till sensorer som markörer
sensors_layer = FeatureGroup(name="Sensors").add_to(m)

for _, row in sensors_df.iterrows():
    popup_content = f"""
    <b>Sensor Name:</b> {row['sensor_name']}<br>
    <b>Latitude:</b> {row['latitude']}<br>
    <b>Longitude:</b> {row['longitude']}<br>
    <b>Address:</b> {row['adress']}, {row['city']}<br>
    <b>Status:</b> {row['status']}<br>
    <b>Activity:</b> {row['activity']}
    """
    folium.Marker(
        location=[row['latitude'], row['longitude']],
        popup=folium.Popup(popup_content, max_width=300),
        icon=folium.Icon(color="green", icon="info-sign")
    ).add_to(sensors_layer)

# Steg 3: Hämta gateway-data från TTN API
# API-url för alla gateways i Sverige
url_sweden = "https://www.thethingsnetwork.org/gateway-data/country/se"

# API-url för gateways inom 200 km från Borlänge
url_borlange = "https://www.thethingsnetwork.org/gateway-data/location?latitude=60.48746&longitude=15.40965&distance=200000"

# Hämta gateway-data för Sverige
response_sweden = requests.get(url_sweden)
if response_sweden.status_code == 200:
    gateways_sweden = response_sweden.json().get('gateways', [])  # Extrahera gateways från dictionary
else:
    print(f"Error fetching gateways in Sweden: {response_sweden.status_code}")
    gateways_sweden = []

# Hämta gateway-data för Borlänge
response_borlange = requests.get(url_borlange)
if response_borlange.status_code == 200:
    gateways_borlange = response_borlange.json().get('gateways', [])  # Extrahera gateways från dictionary
else:
    print(f"Error fetching gateways near Borlänge: {response_borlange.status_code}")
    gateways_borlange = []

# Steg 4: Lägg till gateways från Sverige
sweden_layer = FeatureGroup(name="Gateways in Sweden").add_to(m)

for gateway in gateways_sweden:
    lat = gateway.get('latitude')
    lon = gateway.get('longitude')
    name = gateway.get('description', 'No name')
    if lat and lon:
        popup_content = f"""
        <b>Gateway:</b> {name}<br>
        <b>Latitude:</b> {lat}<br>
        <b>Longitude:</b> {lon}
        """
        folium.Marker(
            location=[lat, lon],
            popup=folium.Popup(popup_content, max_width=300),
            icon=folium.Icon(color="blue", icon="cloud")
        ).add_to(sweden_layer)

# Steg 5: Lägg till gateways från Borlänge
borlange_layer = FeatureGroup(name="Gateways near Borlänge").add_to(m)

for gateway in gateways_borlange:
    lat = gateway.get('latitude')
    lon = gateway.get('longitude')
    name = gateway.get('description', 'No name')
    if lat and lon:
        popup_content = f"""
        <b>Gateway:</b> {name}<br>
        <b>Latitude:</b> {lat}<br>
        <b>Longitude:</b> {lon}
        """
        folium.Marker(
            location=[lat, lon],
            popup=folium.Popup(popup_content, max_width=300),
            icon=folium.Icon(color="red", icon="cloud")
        ).add_to(borlange_layer)

# Steg 6: Lägg till lagerkontroll
LayerControl().add_to(m)

# Steg 7: Lägg till en legend
legend_html = """
<div style="position: fixed; 
            bottom: 50px; left: 50px; width: 250px; height: 150px; 
            background-color: white; border:2px solid grey; z-index:1000; font-size:14px;
            padding: 10px;">
    <b>Legend</b><br>
    <i style="background:blue; width: 10px; height: 10px; border-radius: 50%; display:inline-block;"></i> Gateways in Sweden<br>
    <i style="background:red; width: 10px; height: 10px; border-radius: 50%; display:inline-block;"></i> Gateways near Borlänge<br>
    <i style="background:green; width: 10px; height: 10px; border-radius: 50%; display:inline-block;"></i> Sensors<br>
</div>
"""
m.get_root().html.add_child(folium.Element(legend_html))

# Steg 8: Spara kartan som en HTML-fil
m.save('iot_map_with_sensors.html')
print("Kartan har sparats som 'iot_map_with_sensors.html'")
