# Lab 5: EDA och GIS med Python

## 1. Databearbetning
- Alla fyra filer lästes in och sammanfogades baserat på `timestamp`.
- Saknade värden fylldes i med framåt-fyllning.
- Outliers hanterades med IQR-metoden.
- Data resamplerades till timvis medelvärde och sparades som `cleaned_weather_data.csv`.

## 2. EDA
- Histogram visade fördelningen av temperatur.
- Korrelationsmatris analyserade relationer mellan variabler.
- Tidsserieplot illustrerade temperaturens utveckling över tid.

## 3. GIS-karta
- En karta byggdes med Folium.
- Sensorvärden visas som markörer med popup-fönster.
- Kartan sparades som `iot_map.html`.

## 4. Filstruktur
