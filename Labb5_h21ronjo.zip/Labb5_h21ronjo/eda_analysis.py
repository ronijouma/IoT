import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Läs in den städade datafilen
resampled_data = pd.read_csv('cleaned_weather_data.csv', index_col='timestamp', parse_dates=True)

# Histogram över temperatur
resampled_data['temperature'].hist(bins=30, color='skyblue')
plt.title('Temperaturfördelning')
plt.xlabel('Temperatur (°C)')
plt.ylabel('Frekvens')
plt.show()

# Korrelationsmatris
corr = resampled_data.corr()
sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Korrelationsmatris')
plt.show()

# Tidsserie för temperatur
resampled_data['temperature'].plot(figsize=(12, 6), color='orange')
plt.title('Temperatur över tid')
plt.xlabel('Tid')
plt.ylabel('Temperatur (°C)')
plt.show()
