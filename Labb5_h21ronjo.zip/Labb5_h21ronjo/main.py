import os

# Kör data bearbetning
os.system('python data_processing.py')

# Kör EDA-analys
os.system('python eda_analysis.py')

# Skapa GIS-kartan
os.system('python gis_mapping.py')

