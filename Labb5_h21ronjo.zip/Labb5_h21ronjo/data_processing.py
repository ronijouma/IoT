import pandas as pd
import numpy as np

# Läs in CSV-filer
wind_september = pd.read_csv('wind_data_september.csv')
wind_october = pd.read_csv('wind_data_october.csv')
wind_november = pd.read_csv('wind_data_november.csv')

# Läs in JSON-fil
weather_station = pd.read_json('weatherstation.json')

# Säkerställ att 'timestamp' är i datetime-format i alla datamängder
weather_station['timestamp'] = pd.to_datetime(weather_station['timestamp'])
wind_september['timestamp'] = pd.to_datetime(wind_september['timestamp'])
wind_october['timestamp'] = pd.to_datetime(wind_october['timestamp'])
wind_november['timestamp'] = pd.to_datetime(wind_november['timestamp'])

# Kombinera vinddata
wind_data = pd.concat([wind_september, wind_october, wind_november], ignore_index=True)

# Slå samman väderdata med vinddata baserat på 'timestamp'
combined_data = pd.merge(weather_station, wind_data, on='timestamp', how='inner')

# Hantera saknade värden (framåt-fyllning)
combined_data.fillna(method='ffill', inplace=True)

# Ta bort outliers med IQR-metoden
Q1 = combined_data.quantile(0.25)
Q3 = combined_data.quantile(0.75)
IQR = Q3 - Q1
combined_data = combined_data[~((combined_data < (Q1 - 1.5 * IQR)) | (combined_data > (Q3 + 1.5 * IQR))).any(axis=1)]

# Resampla till timvis medelvärden
combined_data.set_index('timestamp', inplace=True)
resampled_data = combined_data.resample('1H').mean()

# Spara rengjord data till en ny CSV-fil
resampled_data.to_csv('cleaned_weather_data.csv')
