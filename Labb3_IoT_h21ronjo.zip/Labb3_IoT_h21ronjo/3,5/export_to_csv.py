import sqlite3
import pandas as pd

# Anslut till SQLite
conn = sqlite3.connect("sensor_data.db")

# Läsa data och exportera till CSV
df = pd.read_sql_query("SELECT * FROM sensor_data", conn)
df.to_csv("sensor_data.csv", index=False)

print("Data exporterad till sensor_data.csv!")
