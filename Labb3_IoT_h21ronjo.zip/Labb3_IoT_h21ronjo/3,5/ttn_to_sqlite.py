import sqlite3
import paho.mqtt.client as mqtt
import json
from base64 import b64decode
from datetime import datetime

# MQTT-konfiguration
BROKER = "eu1.cloud.thethings.network"
PORT = 1883
USERNAME = "h21ronjo-app@ttn"
PASSWORD = "NNSXS.O6MXULGVR7VWFFODC2TZGCKQEPA7ZLAWWB7Z3BY.BTJ54ERT6RLBK6MTAYKOKL66BCZGVCNHAHOT6M254LKTQ6F2FDBQ"
TOPIC = "v3/+/devices/+/up"

# Anslut till SQLite
conn = sqlite3.connect("sensor_data.db")
cursor = conn.cursor()

def create_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sensor_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        device_id TEXT,
        temperature REAL,
        humidity REAL
    )
    """)
    conn.commit()

def insert_data(timestamp, device_id, temperature, humidity):
    cursor.execute("""
    INSERT INTO sensor_data (timestamp, device_id, temperature, humidity)
    VALUES (?, ?, ?, ?)
    """, (timestamp, device_id, temperature, humidity))
    conn.commit()

# MQTT Callback-funktioner
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to TTN MQTT broker!")
        client.subscribe(TOPIC)
    else:
        print(f"Connection failed with code {rc}")

def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode("utf-8"))
        device_id = payload["end_device_ids"]["device_id"]
        raw_payload = payload["uplink_message"]["frm_payload"]
        decoded_bytes = b64decode(raw_payload)

        # Tolka payload (exempel för CayenneLPP)
        temperature = decoded_bytes[2] + decoded_bytes[3] / 10.0
        humidity = decoded_bytes[5] / 2.0

        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        insert_data(timestamp, device_id, temperature, humidity)

        print(f"Data saved: {timestamp}, {device_id}, {temperature} °C, {humidity} %")
    except Exception as e:
        print(f"Error processing message: {e}")

# Starta MQTT-klient
create_table()
client = mqtt.Client()
client.username_pw_set(USERNAME, PASSWORD)
client.on_connect = on_connect
client.on_message = on_message

try:
    client.connect(BROKER, PORT, 60)
    client.loop_forever()
except KeyboardInterrupt:
    print("Disconnecting...")
    client.disconnect()
    conn.close()
