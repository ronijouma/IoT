﻿using System;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using MQTTnet;
using MQTTnet.Client;

namespace PayloadDecoderApp
{
    public class Program
    {
        private const string Broker = "eu1.cloud.thethings.network";
        private const string AppId = "h21ronjo-app";
        private const string ApiKey = "NNSXS.O6MXULGVR7VWFFODC2TZGCKQEPA7ZLAWWB7Z3BY.BTJ54ERT6RLBK6MTAYKOKL66BCZGVCNHAHOT6M254LKTQ6F2FDBQ";

        public static async Task Main(string[] args)
        {
            Console.WriteLine("MQTTnet ConsoleApp - A The Things Network V3 C# App");
            Console.WriteLine("Press return to exit!");

            var mqttFactory = new MqttFactory();
            var mqttClient = mqttFactory.CreateMqttClient();

            var mqttOptions = new MqttClientOptionsBuilder()
                .WithTcpServer(Broker, 1883)
                .WithCredentials(AppId, ApiKey)
                .WithCleanSession()
                .Build();

            mqttClient.ConnectedAsync += async e =>
            {
                Console.WriteLine("MQTTnet Client -> Connected with result: Success");
                await mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("v3/+/devices/+/up").Build());
                Console.WriteLine("Subscribed to topics: v3/+/devices/+/up");
            };

            mqttClient.ApplicationMessageReceivedAsync += e =>
            {
                try
                {
                    string payload = Encoding.UTF8.GetString(e.ApplicationMessage.Payload);
                    Console.WriteLine($"Timestamp: {DateTime.UtcNow}, Topic: {e.ApplicationMessage.Topic}");
                    Console.WriteLine($"Payload: {BitConverter.ToString(e.ApplicationMessage.Payload)}");

                    HandleDecodedPayload(payload);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing message: {ex.Message}");
                }

                return Task.CompletedTask;
            };

            try
            {
                Console.WriteLine("Connecting to MQTT broker...");
                await mqttClient.ConnectAsync(mqttOptions);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Connection failed: {ex.Message}");
                return;
            }

            Console.WriteLine("Waiting for messages...");
            Console.ReadLine();

            await mqttClient.DisconnectAsync();
        }

        public static void HandleDecodedPayload(string payload)
        {
            try
            {
                var json = JsonDocument.Parse(payload);

                var frmPayload = json.RootElement
                                     .GetProperty("uplink_message")
                                     .GetProperty("frm_payload")
                                     .GetString();

                if (frmPayload == null)
                {
                    throw new Exception("frm_payload is null");
                }

                byte[] data = Convert.FromBase64String(frmPayload);
                Console.WriteLine("Decoded payload bytes: " + BitConverter.ToString(data));

                CayenneLppDecoder.ParseCayennePayload(data);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error handling payload: {ex.Message}");
            }
        }
    }
}
