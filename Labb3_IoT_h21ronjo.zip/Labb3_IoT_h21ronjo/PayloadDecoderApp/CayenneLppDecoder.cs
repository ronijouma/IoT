using System;

public static class CayenneLppDecoder
{
    public static void ParseCayennePayload(byte[] payload)
    {
        int index = 0; // Definiera index i början av metoden
        while (index < payload.Length)
        {
            if (index + 1 >= payload.Length)
            {
                Console.WriteLine($"Error: Incomplete payload at index {index}. Remaining bytes: {payload.Length - index}");
                break;
            }

            byte channel = payload[index++];
            byte type = payload[index++];

            Console.WriteLine($"Processing: Channel {channel}, Type {type:X2} at index {index}");

            try
            {
                switch (type)
                {
                    case 0x67: // Temperatur (2 byte)
                        if (index + 1 >= payload.Length) throw new Exception("Incomplete temperature payload.");
                        int temp = (payload[index++] << 8) | payload[index++];
                        Console.WriteLine($"Channel {channel}: Temperature = {temp / 10.0} °C");
                        break;

                    case 0x68: // Luftfuktighet (1 byte)
                        if (index >= payload.Length) throw new Exception("Incomplete humidity payload.");
                        int hum = payload[index++];
                        Console.WriteLine($"Channel {channel}: Humidity = {hum / 2.0} %");
                        break;

                    case 0x03: // Digital Input (1 byte)
                        if (index >= payload.Length) throw new Exception("Incomplete digital input payload.");
                        int digitalInput = payload[index++];
                        Console.WriteLine($"Channel {channel}: Digital Input = {digitalInput}");
                        break;

                    case 0x40: // Anpassad typ
                        if (index >= payload.Length) throw new Exception("Incomplete custom type payload.");
                        Console.WriteLine($"Channel {channel}: Custom Type = 0x40 (ingen dekodering)");
                        index++; // Hoppa över en byte
                        break;

                    default:
                        Console.WriteLine($"Unknown type: {type} at index {index - 1}");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error decoding type {type:X2} at index {index - 2}: {ex.Message}");
                break;
            }
        }
    }
}
