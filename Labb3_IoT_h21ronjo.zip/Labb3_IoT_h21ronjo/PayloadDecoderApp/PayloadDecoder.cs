using System;
using System.Linq;

public static class PayloadDecoder
{
    // Dekodera en float från hex enligt IEEE-754
    public static float DecodeFloatFromHex(string hex)
    {
        byte[] bytes = Enumerable.Range(0, hex.Length / 2)
            .Select(x => Convert.ToByte(hex.Substring(x * 2, 2), 16))
            .ToArray();
        if (BitConverter.IsLittleEndian)
            Array.Reverse(bytes);
        return BitConverter.ToSingle(bytes, 0);
    }

    // Byte-swap för endianess
    public static byte[] SwapEndian(byte[] input)
    {
        if (input.Length % 4 != 0) throw new ArgumentException("Invalid length for endian swap.");
        for (int i = 0; i < input.Length; i += 4)
        {
            Array.Reverse(input, i, 4);
        }
        return input;
    }
}