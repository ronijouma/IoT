﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

[TestClass]
public class PayloadDecoderTests
{
    [TestMethod]
    public void FloatIEE754_ShouldConvertValidValues_WhenDecodingInput()
    {
        string hex = "42 02 33 33".Replace(" ", "");
        float result = PayloadDecoder.DecodeFloatFromHex(hex);
        Assert.AreEqual(32.55f, result, 0.01);
    }

    [TestMethod]
    public void ByteSwapX4_ShouldConvertValidValues_WhenDecodingInput()
    {
        byte[] input = { 0x33, 0x33, 0x02, 0x42 };
        byte[] swapped = PayloadDecoder.SwapEndian(input);
        CollectionAssert.AreEqual(new byte[] { 0x42, 0x02, 0x33, 0x33 }, swapped);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentException))]
    public void ByteSwapX4_ShouldThrowException_WhenInputLengthIsInvalid()
    {
        byte[] input = { 0x42, 0x6A, 0xCC }; // Ogiltig längd
        PayloadDecoder.SwapEndian(input);
    }
}
