using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

[TestClass]
public class CayenneLppDecoderTests
{
    [TestMethod]
    public void Decode_ShouldDecodeTemperatureCorrectly()
    {
        byte[] payload = { 0x01, 0x67, 0x00, 0xD2 }; // Temperatur: 21.0°C
        var result = CayenneLppDecoder.Decode(payload);
        Assert.AreEqual(21.0f, result["Temperature (Channel 1)"]);
    }

    [TestMethod]
    public void Decode_ShouldDecodeHumidityCorrectly()
    {
        byte[] payload = { 0x02, 0x68, 0x02, 0x58 }; // Luftfuktighet: 60.0%
        var result = CayenneLppDecoder.Decode(payload);
        Assert.AreEqual(60.0f, result["Humidity (Channel 2)"]);
    }

    [TestMethod]
    [ExpectedException(typeof(InvalidOperationException))]
    public void Decode_ShouldThrowExceptionForUnknownType()
    {
        byte[] payload = { 0x01, 0x99, 0x00, 0x00 }; // Ogiltig typ
        CayenneLppDecoder.Decode(payload);
    }
}
